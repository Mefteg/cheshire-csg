
#include <cylinder.h>
#include <ray.h>
#include <intersection.h>
#include <vector.h>
#include "math.h"
#include <iostream>


//#include "headers/intersection.h"
//#include "headers/cylinder.h"

  
  // http://www.cplusplus.happycodings.com/Algorithms/code18.html
Cylinder::Cylinder(const double& radius, const Vector& axis, const Vector& top, const Vector& bottom, const Vector& e, const Vector &c, int refl) :
	Primitive( e, c, refl )
{
	this->radius = radius;
	this->axis = axis;
	this->top = top;
	this->bottom = bottom;
}

//   double radius;	// radius
//   Vector axis;	// normalized axis
//   Vector top;	// top point
//   Vector bottom;	// bottom point

int Cylinder::PMC(const Vector& point)
{
	if((point.y > top.y) && (point.y < bottom.y)) return 0;
	Vector repos = Vector(point.x - bottom.x, point.y - bottom.y, point.z - bottom.z);
	if(sqrt(repos.x) + sqrt(repos.z) > radius) return 0;
	
	return 1;
}

void Cylinder::normale(Intersection inter)
{
	// si nous sommes sur le plan supérieur
	if(inter.pos.y == top.y) inter.normal = Vector(0, 1, 0);

	// si nous sommes sur le plan inférieur
	else if(inter.pos.y == bottom.y) inter.normal = Vector(0, -1, 0);

	// nous sommes sur le corps
	else
	{
		Vector tmp = Vector(bottom.x, bottom.y, bottom.z + (inter.pos.y - bottom.y));
		inter.normal = Normalized(inter.pos - tmp);
	}
}

bool quadric_solve(const double a, const double b, const double c, Intersection& inter1, Intersection& inter2)
{
	double discriminant = (b * b) - (4 * a * c);
	if(discriminant < 0) return false;

	inter1.t = ((b * -1) - sqrt(discriminant)) / (2 * a);
	inter2.t = ((b * -1) + sqrt(discriminant)) / (2 * a);
	
	return true;
}

void swap(Vector& point)
{
	double tmp = point.x;
	point.x = point.y;
	point.y = point.x;
	//point.z = point.z * -1;
}

int Cylinder::Intersect(const Ray& ray, Intersection& inter)
{
	return 0;
}

int Cylinder::Intersect(const Ray& ray, Intersection& inter_a, Intersection& inter_b)
{
	Vector origin = Vector(ray.Origin().x - bottom.x, ray.Origin().y - bottom.y, ray.Origin().z - bottom.z);
	Vector direction = Vector(ray.Direction().x - bottom.x, ray.Direction().y - bottom.y, ray.Direction().z - bottom.z);

	Vector pa = bottom - origin;
	Vector pb = top - origin;
	
	double dx = direction * axis;

	double pax = pa * axis;
	double pbx = pb * axis;
	
	double u[2];
	u[0] = pax / dx;
	u[1] = pbx / dx;
	
	double tmp;
	if (u[1] < u[0])
	{
		tmp = u[0];
		u[0] = u[1];
		u[1] = tmp;
	}
	
	double dpa = direction * pa;

	if(!quadric_solve((direction * direction) - (dx * dx),
		      2.0 * (dx * pax - dpa),
		      pa * pa - pax * pax - radius * radius
			, inter_a, inter_b)) return 0;	

		
	// Intersection
	if (u[0] > inter_a.t) inter_a.t = u[0];
	
	if (u[1] < inter_b.t) inter_b.t = u[1];

	
	// si il n'y a pas d'intersection
	if (inter_a.t > inter_b.t) return 0;
/*
	if((ray(inter_a.t).y > top.y) && (ray(inter_b.t).y > top.y) &&
		(ray(inter_a.t).y < bottom.y) && (ray(inter_b.t).y < bottom.y)
*/	
	inter_a.pos = ray(inter_a.t);
	swap(inter_a.pos);
	inter_a.obj = this;
	normale(inter_a);
	
	inter_b.pos = ray(inter_b.t);
	swap(inter_b.pos);
	inter_b.obj = this;
	normale(inter_b);
	
	return 1;
}
