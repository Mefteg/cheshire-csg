#include "node.h"


Node::Node(void)
{
}


Node::~Node(void)
{
}
