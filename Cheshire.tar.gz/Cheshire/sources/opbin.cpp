#include "opbin.h"


OpBin::OpBin(void)
{
}

OpBin::OpBin(Node * left, Node * right)
{
	this->left = left;
	this->right = right;
}



OpBin::~OpBin(void)
{
}
