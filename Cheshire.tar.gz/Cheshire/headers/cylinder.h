

#ifndef __Cylinder__
#define __Cylinder__


#include "primitive.h"


class Cylinder : public Primitive
{
protected:
  double radius;	// radius
  Vector axis;		// normalized axis
  Vector top;		// top point
  Vector bottom;	// bottom point

public:
  Cylinder() {}
  Cylinder(const double&, const Vector&, const Vector&, const Vector&, const Vector&, const Vector&, int);

  int Intersect( const Ray &, Intersection&);
  int Intersect( const Ray &, Intersection&, Intersection& );
  int PMC(const Vector&);
  void normale (Intersection inter);
  Vector getPosition() { return bottom; };

};

#endif
